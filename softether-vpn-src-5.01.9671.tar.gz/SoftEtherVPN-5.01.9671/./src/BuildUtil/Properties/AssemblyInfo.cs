using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("PacketiX VPN / SoftEther VPN Build Utility")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("SoftEther Corporation")]
[assembly: AssemblyProduct("PacketiX VPN / SoftEther VPN Build Utility")]
[assembly: AssemblyCopyright("Copyright (c) SoftEther Corporation. All Rights Reserved.")]
[assembly: AssemblyTrademark("PacketiX(R) and SoftEther(R) is a registered trademark of SoftEther Corporation.")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("5bf63a11-27da-4ca4-ba9d-a60a0f8e1fd7")]

[assembly: AssemblyVersion("1.0.*")]

// SoftEther VPN Source Code - Developer Edition Master Branch
// Cedar Communication Module


// SecureInfo.c
// Code related to a secure VPN tunnel data for system administrators

#include "CedarPch.h"



// SoftEther VPN Source Code - Developer Edition Master Branch
// Cedar Communication Module


// CedarPch.h
// Header file for grecompile header generation for Cedar

#include <GlobalConst.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <stdarg.h>
#include <time.h>
#include <errno.h>

#include <Mayaqua/Mayaqua.h>
#include <Cedar/Cedar.h>


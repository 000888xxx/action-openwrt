// SoftEther VPN Source Code - Developer Edition Master Branch
// Cedar Communication Module


// CedarPch.c
// Cedar Pre-compile Header Generating Code

#include "CedarPch.h"


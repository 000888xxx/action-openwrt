// SoftEther VPN Source Code - Developer Edition Master Branch
// Cedar Communication Module


// AzureServer.c
// VPN Azure Server

#include "CedarPch.h"



// SoftEther VPN Source Code - Developer Edition Master Branch
// Cedar Communication Module


// SecureInfo.h
// Header of SecureInfo.c

#ifndef	SECUREINFO_H
#define	SECUREINFO_H


#endif	// SECUREINFO_H



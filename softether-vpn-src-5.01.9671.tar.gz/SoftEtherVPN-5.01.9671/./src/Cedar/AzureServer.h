// SoftEther VPN Source Code - Developer Edition Master Branch
// Cedar Communication Module


// AzureServer.h
// Header of AzureServer.c

#ifndef	AZURE_SERVER_H
#define	AZURE_SERVER_H


#endif	// AZURE_SERVER_H



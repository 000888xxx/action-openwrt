// SoftEther VPN Source Code - Developer Edition Master Branch
// Cedar Communication Module


// vpncmdsys.h
// Header of VPN vpncmdsys.c

// Function prototypes
int main(int argc, char *argv[]);
bool ExecProcess(char *exe_name, wchar_t *args_w);
bool IsWindowsNt();





